# Motio — site web

- `index.html` — la vitrine publique, avec le lien de téléchargement de l'APK.
- `app/` — l'espace web : connexion, fil, amis, profil, séances, programmes, historique.

Fichiers statiques, aucune chaîne de build. Ils se posent tels quels sur GitHub Pages.

---

## Mise en route

### 1. Passer le script SQL

Supabase › SQL Editor › coller `sql/01_schema.sql` › Run.

Il ne touche à rien d'existant. Il ajoute `synced_workouts` et `synced_programs`,
les deux seules choses qui vivent encore uniquement sur le téléphone.

### 2. Autoriser l'URL du site pour l'OAuth

Supabase › Authentication › URL Configuration › Redirect URLs :

```
https://motio-training.github.io/motio-updates/app/
http://localhost:8000/app/
```

Sans ça, Google renvoie sur une page d'erreur après la connexion.
`chrono://auth` doit rester dans la liste — c'est le retour de l'application.

### 3. Publier

Copier le contenu du dossier dans le repo `motio-updates` et pousser.
Test local : `python -m http.server 8000`, puis `http://localhost:8000/`.

`app/js/config.js` est déjà rempli avec l'URL et la clé anon du projet, tirées
de `SupabaseConfig.kt`. **C'est un fichier protégé**, au même titre que
`SupabaseConfig.kt`, `UpdateConfig.kt` et `ShareConfig.kt` : je ne le
réécrirai jamais dans une livraison suivante, je livrerai `config.example.js`
à la place.

---

## Ce qui marche dès maintenant, sans toucher à l'application

`shared_sessions` contient déjà l'historique complet avec le détail des séries
depuis la v1.48. Tout ceci lit donc des données qui existent :

- **Connexion** par e-mail et mot de passe, ou par Google. Même compte que
  l'app, même messages d'erreur en français.
- **Inscription** — le pseudo passe par les métadonnées, c'est le déclencheur
  `handle_new_user` qui crée la ligne dans `profiles`, exactement comme
  `Supabase.signUp`.
- **Fil** — séances des personnes suivies, détail des séries dépliable, kudos,
  commentaires (ajout et suppression).
- **Amis** — recherche par pseudo, abonnement, désabonnement.
- **Profil** — pseudo modifiable, nombre de séances, tonnage, séances du mois,
  records 1RM estimés par exercice (formule d'Epley, recalculés à l'affichage
  et jamais stockés, comme `Social.friendStats`).
- **Historique** — toutes tes séances partagées, avec les totaux.

## Ce qui marche après le script SQL, côté web seulement

- **Séances** — liste, création, modification, suppression douce.
  L'éditeur reprend le modèle exact de `WorkoutModel.kt` : mode Chrono /
  Minuteur / Tabata, séries prévues, répétitions cible, récupération, réglages
  Tabata, supersets et circuits par `groupId` adjacent, durée estimée calculée
  avec les mêmes constantes (`WARMUP_SEC`, `EX_WARMUP_SEC`, `SETUP_SEC`,
  `SEC_PER_REP`).
- **Sélecteur d'exercice** — le catalogue par défaut de `ExerciseCatalog.kt`,
  avec recherche insensible aux accents et déduction du matériel par
  `guessGear`. Saisie libre possible.

Attention : tant que la partie Android n'est pas écrite, ces séances restent
sur le serveur. Elles n'apparaîtront pas sur le téléphone.

## Deux limites connues

**Le catalogue est local et personnalisable.** L'app le range dans
`filesDir/exercise_catalog.json` et l'utilisateur peut y ajouter des exercices.
Le web ne connaît que le catalogue d'origine. Ce n'est pas grave — un exercice
n'est qu'un nom, et la saisie libre rattrape le reste — mais si tu veux la
parité, il faudra une troisième table `synced_catalog`, une ligne par personne.

**Le générateur de programme n'est pas porté.** L'écran existe avec ses
réglages, l'algorithme non. Deux voies : le réimplémenter en JavaScript, ou le
déporter dans une fonction Edge Supabase appelée par Android et par le web. La
seconde évite qu'ils divergent au premier ajustement — c'est celle que je
recommande, et c'est aussi la plus rapide à écrire puisque la logique existe
déjà, il s'agit de la transposer une fois.

---

## Le travail restant côté Android

C'est le vrai morceau. Il faut un `CloudSync.kt` qui fasse, pour
`WorkoutStore` et `ProgramStore`, ce que `Social.push` fait déjà pour
l'historique :

1. **Montée** — à chaque `save` et `delete`, écrire dans `synced_workouts` /
   `synced_programs` en upsert sur `(user_id, local_id)`. Le corps de `data`
   est exactement ce que produit `workoutToJson` / `toJson`, sans rien changer.
2. **Descente** — au lancement et au retour au premier plan, lire
   `?updated_at=gt.<dernier_sync>` et fusionner dans le magasin local.
3. **File d'attente hors ligne** — une liste de `local_id` en attente dans les
   SharedPreferences, rejouée à la prochaine connexion. L'upsert étant
   idempotent, rejouer ne duplique rien.
4. **Conflits** — dernier-écrit-gagne sur `updated_at`, qui est tenu par un
   déclencheur Postgres et non par le client.
5. **Suppressions** — écrire `deleted_at`, jamais un `DELETE`. Sinon le premier
   téléphone hors ligne qui renvoie sa copie locale ressuscite ce qu'un autre
   a effacé.

Deux points d'attention repérés dans le code existant :

- `Workout.id` et `Program.id` sont des millisecondes générées par
  `System.currentTimeMillis()`. Deux appareils qui créent une séance dans la
  même milliseconde produiraient le même identifiant. C'est très improbable,
  mais la synchronisation transforme un bug improbable en corruption
  silencieuse — je suggère de basculer sur un UUID comme `Session.uid`, avec
  repli sur l'ancien identifiant pour les séances déjà enregistrées.
- `WorkoutStore.rev` et `ProgramStore.rev` sont déjà les bons points
  d'accroche pour déclencher une montée : ils sont incrémentés à chaque
  écriture.

Dis-moi quand tu veux que j'écrive ce `CloudSync.kt` — c'est la prochaine
étape logique, et elle demande un `versionCode` 66 / `versionName` 1.65.
