-- ===========================================================================
-- Motio — synchronisation des modèles de séance et des programmes
--
-- À passer dans Supabase › SQL Editor. Rejouable sans risque.
--
-- CE QUI EXISTE DÉJÀ et n'est pas touché ici :
--   profiles, follows, shared_sessions, kudos, comments.
--
-- CE QUE CE SCRIPT AJOUTE : les deux seules choses qui vivent encore
-- uniquement sur le téléphone, dans filesDir/workouts.json et
-- filesDir/programs.json.
--
-- Conventions reprises de shared_sessions, pour que tout se ressemble :
--   user_id   → auth.users(id)
--   local_id  → l'identifiant local de l'app (Workout.id / Program.id, des
--               millisecondes) en texte
--   unicité (user_id, local_id) → l'écriture est idempotente, rejouer une
--               synchronisation met à jour au lieu de dupliquer
--
-- Le contenu part dans une colonne `data` jsonb qui reprend MOT POUR MOT ce
-- qu'écrivent WorkoutStore.workoutToJson et ProgramStore.toJson. Ajouter un
-- champ au modèle Kotlin ne demandera donc aucune migration ici. `name` et
-- `category` sont dupliqués en colonnes réelles parce qu'on trie dessus.
-- ===========================================================================

-- ------------------------------------------------- modèles de séance --
create table if not exists public.synced_workouts (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  local_id    text not null,
  name        text not null,
  category    text not null default 'Push',
  data        jsonb not null default '{}'::jsonb,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz,
  unique (user_id, local_id)
);

-- ------------------------------------------------------- programmes --
create table if not exists public.synced_programs (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  local_id    text not null,
  name        text not null,
  data        jsonb not null default '{}'::jsonb,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz,
  unique (user_id, local_id)
);

create index if not exists synced_workouts_user_maj
  on public.synced_workouts (user_id, updated_at desc);
create index if not exists synced_programs_user_maj
  on public.synced_programs (user_id, updated_at desc);

-- ===========================================================================
-- Row Level Security
--
-- Contrairement à shared_sessions, RIEN n'est visible des abonnés : un modèle
-- de séance est un brouillon personnel. Si un jour tu veux les rendre
-- partageables, ce sera une politique en plus, pas une modification de
-- celles-ci.
-- ===========================================================================

alter table public.synced_workouts enable row level security;
alter table public.synced_programs enable row level security;

drop policy if exists "synced_workouts_lecture" on public.synced_workouts;
create policy "synced_workouts_lecture" on public.synced_workouts
  for select to authenticated using (user_id = auth.uid());

drop policy if exists "synced_workouts_insertion" on public.synced_workouts;
create policy "synced_workouts_insertion" on public.synced_workouts
  for insert to authenticated with check (user_id = auth.uid());

drop policy if exists "synced_workouts_maj" on public.synced_workouts;
create policy "synced_workouts_maj" on public.synced_workouts
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists "synced_workouts_suppression" on public.synced_workouts;
create policy "synced_workouts_suppression" on public.synced_workouts
  for delete to authenticated using (user_id = auth.uid());

drop policy if exists "synced_programs_lecture" on public.synced_programs;
create policy "synced_programs_lecture" on public.synced_programs
  for select to authenticated using (user_id = auth.uid());

drop policy if exists "synced_programs_insertion" on public.synced_programs;
create policy "synced_programs_insertion" on public.synced_programs
  for insert to authenticated with check (user_id = auth.uid());

drop policy if exists "synced_programs_maj" on public.synced_programs;
create policy "synced_programs_maj" on public.synced_programs
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists "synced_programs_suppression" on public.synced_programs;
create policy "synced_programs_suppression" on public.synced_programs
  for delete to authenticated using (user_id = auth.uid());

-- ===========================================================================
-- updated_at tenu par la base.
--
-- Un client qui oublie de le mettre à jour casserait la résolution de conflit
-- en dernier-écrit-gagne. Ce n'est donc pas au client de le renseigner.
-- ===========================================================================

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists synced_workouts_touch on public.synced_workouts;
create trigger synced_workouts_touch before update on public.synced_workouts
  for each row execute function public.touch_updated_at();

drop trigger if exists synced_programs_touch on public.synced_programs;
create trigger synced_programs_touch before update on public.synced_programs
  for each row execute function public.touch_updated_at();

-- ===========================================================================
-- Suppression de compte : si tu as déjà une fonction delete_my_account,
-- pense à y ajouter ces deux tables. Le `on delete cascade` sur user_id fait
-- déjà le travail lorsque la ligne auth.users disparaît, mais une fonction
-- écrite avant l'existence de ces tables ne les connaît pas.
-- ===========================================================================
